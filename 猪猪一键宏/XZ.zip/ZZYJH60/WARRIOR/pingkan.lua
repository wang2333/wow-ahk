-- 创建全局变量，用于存储技能状态
yingyong = false
shunpi = false
pingkan = false
chuiji = false

-- 创建一个框架，用于每帧更新技能状态
local frame = CreateFrame("Frame")

-- 每帧检查技能状态
frame:SetScript("OnUpdate", function(self, elapsed)
    -- 判断技能是否激活，并更新变量
    if IsCurrentSpell("英勇打击") then
        yingyong = true
    else
        yingyong = false
    end

    if IsCurrentSpell("顺劈斩") then
        shunpi = true
    else
        shunpi = false
    end

    if IsCurrentSpell("攻击") then
        pingkan = true
    else
        pingkan = false
    end

        if IsCurrentSpell("槌击") then
        chuiji = true
    else
        chuiji = false
    end
end)

