if UnitClassBase("player")~="DRUID" then
    return
end

-- 创建一个框架，用于每帧更新技能状态
local frame = CreateFrame("Frame")

-- 每帧检查技能状态
frame:SetScript("OnUpdate", function(self, elapsed)



-- 获取猎豹形态法术的消耗信息
local spellCost = GetSpellPowerCost("猎豹形态")
if spellCost then
    bianxing = spellCost[1].cost
else
    bianxing = 0  -- 如果没有消耗信息，默认值为0
end

-- 获取野性印记法术的消耗信息
local spellCost = GetSpellPowerCost("野性印记")
if spellCost then
    yinji = spellCost[1].cost
else
    yinji = 0
end

-- 获取荆棘术法术的消耗信息
local spellCost = GetSpellPowerCost("荆棘术")
if spellCost then
    jingji = spellCost[1].cost
else
    jingji = 0
end

-- 获取清晰预兆法术的消耗信息
local spellCost = GetSpellPowerCost("清晰预兆")
if spellCost then
    qingxi = spellCost[1].cost
else
    qingxi = 0
end


local spellCost = GetSpellPowerCost("割碎(豹)")
if spellCost then
    maogesui = spellCost[1].cost
else
    maogesui = 0  -- 如果没有消耗信息，默认值为0
end

local spellCost = GetSpellPowerCost("撕碎")
if spellCost then
    sisui = spellCost[1].cost
else
    sisui = 0  -- 如果没有消耗信息，默认值为0
end

local spellCost = GetSpellPowerCost("扫击")
if spellCost then
    saoji = spellCost[1].cost
else
    saoji = 0  -- 如果没有消耗信息，默认值为0
end

local spellCost = GetSpellPowerCost("凶猛撕咬")
if spellCost then
    xiongmeng = spellCost[1].cost
else
    xiongmeng = 0  -- 如果没有消耗信息，默认值为0
end



local spellCost = GetSpellPowerCost("撕扯")
if spellCost then
    siche = spellCost[1].cost
else
    siche = 0  -- 如果没有消耗信息，默认值为0
end

local spellCost = GetSpellPowerCost("爪击")
if spellCost then
    zhuaji = spellCost[1].cost
else
    zhuaji = 0  -- 如果没有消耗信息，默认值为0
end

local spellCost = GetSpellPowerCost(414689)
if spellCost then
    maoyangyan = spellCost[1].cost
else
    maoyangyan = 0  -- 如果没有消耗信息，默认值为0
end
end)

