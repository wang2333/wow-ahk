# LibOO-1.0

LibOO-1.0 provides an object-oriented framework to World of Warcraft addons. It is based on the framework that was developed for TellMeWhen 5.0.0

Check https://wow.curseforge.com/projects/liboo-1-0/pages/api for documentation.