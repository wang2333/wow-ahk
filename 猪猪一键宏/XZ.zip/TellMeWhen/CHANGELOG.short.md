
## v10.2.3
* Fix #2148 - Aura Tracking broken in WoW 1.15.1


[View Full Changelog](https://github.com/ascott18/TellMeWhen/blob/f2108653dafe9dbaf720a6d1ff80874c162267fe/CHANGELOG.md)
