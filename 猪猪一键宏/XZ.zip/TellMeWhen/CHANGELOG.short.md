
## v11.1.0
* Fixes for WoW 11.1
* Fix: #2258 - Error when changing icon sorting within a group
* Fix: #2256 - Some currency conditions missing on characters that have never encountered a particular currency.
* Fix: #2253 - Listen to better events to pick up all weapon enchant changes


[View Full Changelog](https://github.com/ascott18/TellMeWhen/blob/5aaf32c3b0446cb343467e2b3d597c6fb1500359/CHANGELOG.md)
